# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# Preprocess the PAN2012 datset
# * puts the resulting dataset into a panadas class (saved in pickled format)
# * pandas columns: "type_flg", "conv_id", "author_id", "chat_line"
# * type_flg: p = predator, v = victim, x = other
# * chats are preprocessed as follows:
#   - convert new lines and tabs
#   - clean up XML character encodings
#   - clean up non alpha and numeric characters
#   - convert numbers <= 18 to #NUM-MINOR, and all others to #NUM
#   - clean up repeating double spaces and triple characters
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------


import pandas as pd 
import xml.etree.ElementTree as et 
import comp6321_module as prj 


# ---------------------------------------------------------------------
def isascii(char):
    try:
        char.decode('ascii')
    except:
        return False
    return True

# ---------------------------------------------------------------------
# clean up the chat-line according to the rules layed out in the 
# project report

def preprocess_chat_line(line):
    if line is None: return " "
    keep_chars = ['.', '?']
    delete_chars = ["'"]
    
    # convert new lines and tabs
    line = line.replace("\n", "")
    line = line.replace("\t", " ")

    # clean up XML character encodings
    line = line.replace("&quot;", "")
    line = line.replace("&amp;", "")
    line = line.replace("&apos;", "")
    line = line.replace("&lt;", "")
    line = line.replace("&gt;", "")
    line = line.replace("quot;", "")
    line = line.replace("amp;", "")
    line = line.replace("apos;", "")
    line = line.replace("lt;", "")
    line = line.replace("gt;", "")
    
    new_line = ""
    i = 0

    # clean up non alpha and numeric characters
    # convert numbers <= 18 to #NUM-MINOR, and all others to #NUM
    while i < len(line):
        if line[i].isdigit():
            xnum = ""
            while i < len(line) and line[i].isdigit():
                xnum += line[i]
                i += 1
            try:
                num = int(xnum)
                if num <= 18:
                    new_line += "#NUM-MINOR "
                else:
                    new_line += "#NUM "
            except:
                pass
        else:
            if (isascii(line[i]) and line[i].isalnum()) or line[i] in keep_chars: 
                new_line += line[i].lower()
            else:
                if line[i] not in delete_chars: 
                    new_line += " "
        i += 1

    line = new_line
    new_line = ""

    # clean up repeating double spaces and triple characters
    for i in range(len(line)):
        if i < len(line) - 2:
            if line[i] == line[i+1] and line[i] == line[i+2]: 
                continue
        if line[i] == ' ' and i < len(line) - 1:
            if line[i + 1] == ' ': 
                continue
        new_line += line[i]

    new_line = new_line.strip()

    # breakup line into MAX_CHAT_LEN segments (keep border words intact)
    lines = []
    end = prj.MAX_CHAT_LEN;
    loop_ctr = prj.MAX_CHAT_LEN // 2;
    
    while loop_ctr > 0:
        xlen = len(new_line)
        if xlen < end:
            lines.append(new_line.strip())
            break
        i = end - 1
        if new_line[i] == ' ':
            lines.append(new_line[0:end].strip())
            new_line = new_line[end:]
        else:
            while i > 0:
                if new_line[i] == ' ': 
                    break
                else:
                    i -= 1
            lines.append(new_line[0:i].strip())
            new_line = new_line[i:]
        loop_ctr -= 1

    return lines

# ---------------------------------------------------------------------
# do the actual preprocessing of the PAN-2012 dataset

def preprocess_file(filename):
    prj.print_write("parsing xml:", filename)
    root = et.parse(filename).getroot()

    chat_data = []
    ignored = []
    message_ctr = 0;

    print('processing message:', message_ctr, end='\r')

    with open('chatlines.txt', 'w+') as f:
        for conversations in root.findall("conversation"):
            type_flg = "x"
            conv_id = conversations.attrib.get("id")
            for messages in conversations:
                message_ctr += 1
                author_id = messages.find("author").text
                raw_chat_line = messages.find("text").text
                if message_ctr % 5000 == 0:
                    #print('message:', raw_chat_line)
                    print('processing message:', message_ctr, end='\r')
                if raw_chat_line is None: 
                    continue
                if len(raw_chat_line) < 768:
                    chat_lines = preprocess_chat_line(raw_chat_line)
                    for chat_line in chat_lines:
                        if chat_line:
                            f.write(chat_line + "\n")
                            chat_data.append({"type_flg": type_flg, "conv_id": conv_id, "author_id": author_id, "chat_line": chat_line})
                else:
                    if raw_chat_line:
                       ignored.append(raw_chat_line)
    
    with open('ignored.txt', 'w+') as f:
        for line in ignored:
            try:
                f.write("--------------------------------------------------------\n")
                f.write(line + "\n")
            except:
                pass
    prj.print_write("all ignored chats stored in file ignored.txt for reference")
                       
    prj.print_write('total messages:', message_ctr)
    prj.print_write("all accepted chats stored in file chatlines.txt for reference")

    return chat_data


# ---------------------------------------------------------------------
# main preprocess function

def run_preprocess(raw_dataset_filename, pandas_dataframe_filename, predator_id_filename):

    prj.clean_print_write()

    chat_data = preprocess_file(raw_dataset_filename)

    prj.print_write("building dataframe...")
    out_df = pd.DataFrame(chat_data, columns = ["type_flg", "conv_id", "author_id", "chat_line"])

    prj.print_write("loading preditor data...")
    with open(predator_id_filename) as f:
        line_list = f.readlines()

    save_list = []

    for line in line_list:
        line = line.replace("\n", "")
        if not line: continue
        save_list.append(line)

    pred_df = pd.DataFrame(save_list, columns = ["pred_id"])

    prj.print_write("flagging preditors and victims in data...")
    conv_with_preds = out_df.conv_id[out_df.author_id.isin(pred_df.pred_id)].drop_duplicates()
    out_df.type_flg[out_df.conv_id.isin(conv_with_preds)] = "v"
    out_df.type_flg[out_df.author_id.isin(pred_df.pred_id)] = "p"

    prj.print_write("saving dataframes...")
    out_df.to_pickle(pandas_dataframe_filename)

    prj.print_write('done preprocessing.')

