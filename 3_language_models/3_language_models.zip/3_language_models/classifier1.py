# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# performs final classification and prints performance metrics
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
import numpy as np
import pandas as pd 
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from pan2012 import *

import comp6321_module as prj


# ---------------------------------------------------------------------
def classify_method_1(lm_scores_fn, p_langauge_model_fn, v_langauge_model_fn, n_langauge_model_fn):

    #prj.clean_print_write()

    is_cuda = torch.cuda.is_available()
    if is_cuda:
        device = torch.device("cuda")
        print("GPU is available")
    else:
        device = torch.device("cpu")
        print("GPU not available, CPU used")

    # load or create the data that has already been evaluated by the 3 speaker classifiers
    pan_data = Pan2012Data(p_langauge_model_fn, v_langauge_model_fn, n_langauge_model_fn)
    pan_data.load(lm_scores_fn)


    # ---------------------------------------------------------------------
    # sum up the speaker rates and choose the highest value
    # naive way of classifying but lets us see the performance of the language models

    TP = 0
    TN = 0
    FP = 0
    FN = 0
    total_p = 0
    total_authors = 0

    authors = pan_data.get_list_of_all_authors()

    for author in authors:

        author_lst = pan_data.get_author_data(author)

        author_hold = author_lst[0]
        author_type = author_hold['type_flg']

        total_p_rate = 0
        total_v_rate = 0
        total_n_rate = 0
        total_authors += 1

        for chat_line in author_lst:
            total_p_rate += chat_line['p_rate']
            total_v_rate += chat_line['v_rate']
            total_n_rate += chat_line['n_rate']

        if total_p_rate > total_v_rate and total_p_rate > total_n_rate:
            ptype = 'p'
        else:
            if total_v_rate > total_p_rate and total_v_rate > total_n_rate:
                ptype = 'v'
            else:
                if total_n_rate > total_p_rate and total_n_rate > total_v_rate:
                    ptype = 'x'
                else:
                    ptype = 'u'
    
        if author_type == 'p': 
            total_p += 1
            if ptype == 'p':
                TP += 1
            else:
                FN += 1
        else:
            if ptype == 'p':
                FP += 1
            else:
                TN += 1

        prj.print_write("author {0}     => {1}-{2}".format(author, author_type, ptype))

    prj.print_write(' ')

    accuracy = (TP + TN) / (TP + TN + FP + FN)
    TPR = TP / (TP + FN)      # recall
    FPR = FP / (FP + TN)
    precision = TP / (TP + FP) 

    prj.print_write('* summary:')
    prj.print_write('         accuracy: {0:.3f}'.format(accuracy))
    prj.print_write('        precision: {0:.3f}'.format(precision))
    prj.print_write('       recall/TPR: {0:.3f}'.format(TPR))
    prj.print_write('              FPR: {0:.3f}'.format(FPR))
    prj.print_write('               TP: {0}'.format(TP))
    prj.print_write('               TN: {0}'.format(TN))
    prj.print_write('               FP: {0}'.format(FP))
    prj.print_write('               FN: {0}'.format(FN))
    prj.print_write('  preditors total: {0}'.format(total_p))
    prj.print_write('    total authors: {0}'.format(total_authors))


