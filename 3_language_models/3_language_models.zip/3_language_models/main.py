# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# The main starting point for running the code
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
from xpreprocess import *
from xtrain_speaker import *
from xevaluate_speakers import *
from pan2012 import *
from classifier1 import *

# ---------------------------------------------------------------------
# helper functions
def run_preprocessor():
    # run this to preprocess the training dataset
    pan2012_dataset_filename = r'./pan2012_datasets/pan2012-training-corpus.xml'
    pan2012_predator_ids = r'./pan2012_datasets/pan2012-spi-identification-training-corpus.txt'
    pandas_filename = r'./data/training_dataset_pandas.pkl'
    run_preprocess(pan2012_dataset_filename, pandas_filename, pan2012_predator_ids)

    # run this to preprocess the test dataset
    pan2012_dataset_filename = r'./pan2012_datasets/pan2012-test-corpus.xml'
    pan2012_predator_ids = r'./pan2012_datasets/pan2012-spi-identifcation-testing-corpus.txt'
    pandas_filename = r'./data/testing_dataset_pandas.pkl'
    run_preprocess(pan2012_dataset_filename, pandas_filename, pan2012_predator_ids)

    return


# *********************************************************************
# main starting point for running the code
# follow the sequence outlined below
# if a sequence takes too much time you can generally substitute the 
# resultant with data from ./mydataset
# *********************************************************************

prj.clean_print_write()     # check output.txt for the output of the run


# ---------------------------------------------------------------------
# 1. preprocess the PAN2012 Datasets 
#    a. goto function run_preprocessor() and edit the code to run what you want
#    b. there is alot of data in the datasets so it might take 5-10 mins to complete
#    c. the preprocessed output files are soted in ./data
#    d. an output is created 'chatlines.txt' that shows the lines added to the Pandas DB 
#    e. an output is created 'ignored.txt' that shows the lines ignored by the preprocessor 
# ---------------------------------------------------------------------
prj.print_write('step 1. preprocessing...')
run_preprocessor()


# ---------------------------------------------------------------------
# 2. train the language models 
#    a. the process can take a long time - comment out the lines you don't need
#    b. the learning rate and batch size are a function of the number of samples you want to train on. 
#    Use the following as a guideline:
#        1000  -> lr=0.005, bs=30, early stop at 0.07
#        5000  -> lr=0.005, bs=40, early stop at 0.14
#        10000 -> lr=0.001, bs=40, early stop at 0.18
#        15000 -> lr=0.001, bs=50, early stop at 0.19
#        20000 -> lr=0.001, bs=50, early stop at 0.19
# ---------------------------------------------------------------------
prj.print_write('step 2. training the language models...')

build_predator_language_model('./data/training_dataset_pandas.pkl', 5000, 0.005, 30, 0.07, './data/predator_model_5k.pkl')
build_victim_language_model('./data/training_dataset_pandas.pkl', 5000, 0.005, 30, 0.07, './data/victim_model_5k.pkl')
build_normal_language_model('./data/training_dataset_pandas.pkl', 5000, 0.005, 30, 0.07, './data/normal_model_5k.pkl')


# ---------------------------------------------------------------------
# 3. test & validate 
#   a. runs scores and validates on validation/testing data against the 3 models
#   c. since long to run, minimize the amount of data. good number is 1000
#   d. review and specify call parameters:
#      - sample_count (i.e. # of chat-lines to process)
#      - which language model to use
# ---------------------------------------------------------------------
prj.print_write('step 3. testing and validation...')

validate_scores('./data/training_dataset_pandas.pkl', 500,  # specify the number of sample chat-lines to score
               './data/predator_model_5k.pkl',             # specify which language model to use
               './data/victim_model_5k.pkl',               # ...
               './data/normal_model_5k.pkl')               # ...


# ---------------------------------------------------------------------
# 4. classification part 1 of 2 
#   a. gets scores against the 3 models
#   b. long process so data is saved before classification (next part)
#      allows for working on the classifier in isolation without waiting for 
#      this part to complete everytime
#   c. since so long to run, minimize the amount of data
#      since # samples indicate authors, all the chatlines for tha author are processed
#      this means the amount of data to process adds up quickly
#      good numbers include 100 preditors and 500 normal authors
#      if you can't wait use whats available under ./mydata
#   d. review and specify call parameters:
# ---------------------------------------------------------------------
prj.print_write('step 4. classification 1/2...')

pan_data = Pan2012Data('./data/predator_model_5k.pkl', './data/victim_model_5k.pkl', './data/normal_model_5k.pkl')
pan_data.create_training_data('./data/training_dataset_pandas.pkl', 30, 150)
pan_data.save('./data/lm_training_scores.pkl')

pan_data = Pan2012Data('./data/predator_model_15k.pkl', './data/victim_model_15k.pkl', './data/normal_model_15k.pkl')
pan_data.create_training_data('./data/testing_dataset_pandas.pkl', 30, 150)
pan_data.save('./data/lm_testing_scores.pkl')


# ---------------------------------------------------------------------
# 5. classification part 2 of 2 
#   a. does final classification 
#   b. measures performance
# ---------------------------------------------------------------------
prj.print_write('step 4. classification 2/2...')

classify_method_1('./data/lm_training_scores.pkl',
                  './data/predator_model_5k.pkl', './data/victim_model_5k.pkl', './data/normal_model_5k.pkl')

classify_method_1('./data/lm_testing_scores.pkl',
                  './data/predator_model_5k.pkl', './data/victim_model_5k.pkl', './data/normal_model_5k.pkl')


prj.print_write('done.')

