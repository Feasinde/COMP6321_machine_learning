# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# does part 1 of 2 of validation on validation/testing data against the 3 
# language models. part 2 is the classification
# coded in 2 parts since this part is long
# work done here is saved so that work on part 2 (classification) can be done
# without having to wait for this part to complete everytime
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
import numpy as np
import pandas as pd 
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import re

from speaker_by_character_module import *
from measure_speaker_module import *

import comp6321_module as prj


# ---------------------------------------------------------------------
def gen_validation_data(df, df_type, start, count):
    xdf = df[df.type_flg == df_type][start : start + count + 1]
    reply = list(zip(xdf.type_flg, xdf.chat_line))
    return reply


# ---------------------------------------------------------------------
def get_validation_data(df, start_from_idx, n_count):
    validation_chats = []
    validation_chats.extend(gen_validation_data(df, 'p', start_from_idx, n_count))
    validation_chats.extend(gen_validation_data(df, 'v', start_from_idx, n_count))
    validation_chats.extend(gen_validation_data(df, 'x', start_from_idx, n_count))
    return validation_chats


# ---------------------------------------------------------------------
def evaluate_chat(eval_speaker, xtype, original_words, predator_words, victim_words, normal_words):
    
    p_rate, v_rate, n_rate = eval_speaker.evaluate_words(xtype, original_words, predator_words, victim_words, normal_words)
    
    score_p = 'p({0:.3f})'.format(p_rate)
    score_v = 'v({0:.3f})'.format(v_rate)
    score_x = 'x({0:.3f})'.format(n_rate)

    prj.xwrite('--------------------------------------------------------------------------')
    prj.xwrite('type:', xtype, "scores: " + score_p + " " + score_v + " " + score_x)
    prj.xwrite('original:', original_words)
    prj.xwrite('predator:', predator_words)
    prj.xwrite('victim  :', victim_words)
    prj.xwrite('normal  :', normal_words)


# ---------------------------------------------------------------------
def get_words(sentence):
    words = list(filter(None, re.split('[ ]|(\.|\?|\n)', sentence)))
    return words


# ---------------------------------------------------------------------
def print_stats(eval_speaker):

    prj.print_write(' ')
    prj.print_write('--------------------------------------------------------------------------')
    prj.print_write('- overall summary                                                        -')
    prj.print_write('--------------------------------------------------------------------------')
    total, pctr, vctr, nctr, unknown = eval_speaker.pchat_counters()
    prj.print_write('* preditor chat total:', total)
    prj.print_write('  p ctr:', pctr)
    prj.print_write('  v ctr:', vctr)
    prj.print_write('  n ctr:', nctr)
    prj.print_write('  ? ctr:', unknown)
    prj.print_write('  accuracy : {0:.3f}'.format(eval_speaker.p_accuracy()))
    prj.print_write('  precision: {0:.3f}'.format(eval_speaker.p_precision()))
    prj.print_write('  recall   : {0:.3f}'.format(eval_speaker.p_recall()))
    prj.print_write('--------------------------------------------------------------------------')
    total, pctr, vctr, nctr, unknown = eval_speaker.vchat_counters()
    prj.print_write('* victim chat total:', total)
    prj.print_write('  p ctr:', pctr)
    prj.print_write('  v ctr:', vctr)
    prj.print_write('  n ctr:', nctr)
    prj.print_write('  ? ctr:', unknown)
    prj.print_write('  accuracy : {0:.3f}'.format(eval_speaker.v_accuracy()))
    prj.print_write('  precision: {0:.3f}'.format(eval_speaker.v_precision()))
    prj.print_write('  recall   : {0:.3f}'.format(eval_speaker.v_recall()))
    prj.print_write('--------------------------------------------------------------------------')
    total, pctr, vctr, nctr, unknown = eval_speaker.nchat_counters()
    prj.print_write('* normal chat total:', total)
    prj.print_write('  p ctr:', pctr)
    prj.print_write('  v ctr:', vctr)
    prj.print_write('  n ctr:', nctr)
    prj.print_write('  ? ctr:', unknown)
    prj.print_write('  accuracy : {0:.3f}'.format(eval_speaker.n_accuracy()))
    prj.print_write('  precision: {0:.3f}'.format(eval_speaker.n_precision()))
    prj.print_write('  recall   : {0:.3f}'.format(eval_speaker.n_recall()))
    prj.print_write('--------------------------------------------------------------------------')


# ---------------------------------------------------------------------
def validate_scores(dataset_filename, sample_count, p_model_fn, v_model_fn, n_model_fn):

    #prj.clean_print_write()
    is_cuda = torch.cuda.is_available()
    if is_cuda:
        device = torch.device("cuda")
        prj.print_write("GPU is available")
    else:
        device = torch.device("cpu")
        prj.print_write("GPU not available, CPU used")

    # get the full set of PAN2012 chats from preprocessed chat db
    prj.print_write('reading in chat data from: ', dataset_filename)
    df = pd.read_pickle(dataset_filename)

    prj.print_write('getting chat-lines...')
    validation_chats = get_validation_data(df, 20000, sample_count)

    print('loading speaker models....')

    pred_speaker = SpeakerByCharacter.load(p_model_fn)
    victim_speaker = SpeakerByCharacter.load(v_model_fn)
    normal_speaker = SpeakerByCharacter.load(n_model_fn)

    print('scoring chat-lines....')

    eval_speaker = MeasureSpeaker()

    type_pos = 0
    chat_pos = 1

    # only use a certain max number of previous words
    PREV_WORD_MAX = 10

    # process chat-lines...
    for xchat in validation_chats:
        xtype = xchat[type_pos]
        chat = xchat[chat_pos]
        words = get_words(chat)
        print(words)
        pred_words = pred_speaker.speak_next_from_current(words, PREV_WORD_MAX)
        victim_words = victim_speaker.speak_next_from_current(words, PREV_WORD_MAX)
        normal_words = normal_speaker.speak_next_from_current(words, PREV_WORD_MAX)
        evaluate_chat(eval_speaker, xtype, words, pred_words, victim_words, normal_words)
    
    print_stats(eval_speaker)

