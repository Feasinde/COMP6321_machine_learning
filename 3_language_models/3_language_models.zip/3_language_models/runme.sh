#!/bin/bash
echo export PYTHONPATH=..
python3 main.py



