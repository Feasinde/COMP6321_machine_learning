# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# Holds the main class that trains the 3 language models
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import sklearn
import sklearn.preprocessing
import random
import pickle
import time
import re
import comp6321_module as prj


# ---------------------------------------------------------------------
# class that trains the 3 language models
# ---------------------------------------------------------------------
class SpeakerByCharacter():
    def __init__(self):
        # use GPU if available
        if torch.cuda.is_available():
            self.device = torch.device("cuda")
            #self.device = torch.device("cpu")
        else:
            self.device = torch.device("cpu")

        return

    # ---------------------------------------------------------------------
    def setup_encoding_from_sample_data(self, sample_data, max_line_length):
        
        # set the maximum length of a line - if it's too big it will take too long to train
        #self.MAX_LEN = len(max(sample_data, key=len))
        self.MAX_LEN = max_line_length
        
        unique_chars_in_chat = list(x for x in set(''.join(sample_data)))
        unique_chars_in_chat.append('\n')

        self.FEATURE_DIM = len(unique_chars_in_chat) 

        # create a dictionary that maps integers (index) to the unique characters
        # the integer value corresponds to the '1' in the one-hot vector (effectively the category)
        self.index_to_char_dict = dict(enumerate(unique_chars_in_chat))

        # create a dictionary that maps the unique characters to an integer (idex)
        # the integer value corresponds to the '1' in the one-hot vector (effectively the category)
        self.char_to_index_dict = {char: ind for ind, char in self.index_to_char_dict.items()}


    # ---------------------------------------------------------------------
    # input: character to encode
    # output: numpy array with the encoded one-hot vector of the input character
    #         -> size(self.MAX_LEN,len(unique_chars_in_chat)
    # e.g. -> "j" -> [0 0 1...]
    def one_hot_encode(self, character):
        one_hot_vector = [0] * self.FEATURE_DIM
        idx = self.char_to_index_dict[character]
        one_hot_vector[idx] = 1
        return one_hot_vector


    # ---------------------------------------------------------------------
    # input: one-hot-vector
    # output: character corresponding to the one-hot vector, and it's index (ie category)
    # e.g. -> [0 0 1...] -> "j"
    def one_hot_decode(self, one_hot_vector):
        char_idx = torch.max(one_hot_vector, dim=0)[1].item()
        xchar = self.index_to_char_dict[char_idx]
        return xchar 


    # ---------------------------------------------------------------------
    # input: 1 complete sentence
    # output: np array containing the one-hot vector for every letter in the sentence ([[...],[...]...] 
    #         -> size(self.MAX_LEN,len(one-host-vector))
    # e.g. -> "john" -> [[0 0 1], [0 1 0]...]
    def encode_sentence(self, sentence):
        reply_vectors = []
        space_vector = self.one_hot_encode(' ')

        sentence = sentence.strip()
        sentence += " \n"             # add end of sentence terminator
        xlen = len(sentence)

        for i in range(self.MAX_LEN):
            if i < xlen:
                enc = self.one_hot_encode(sentence[i])
                reply_vectors.append(enc)
            else:
                reply_vectors.append(space_vector)

        return reply_vectors
        

    # ---------------------------------------------------------------------
    # input: array of one-hot vectors
    # output: sentence as a string, array of category indexes
    # e.g. -> [[0 0 1], [0 1 0]...] -> "john", [10, 5, 20...]
    def decode_sentence(self, sentence_vectors):
        xlen = len(sentence_vectors)
        reply_string = ''
        for i in range(xlen):
            xchar = one_hot_decode(sentence_vectors[i])
            reply_string += xchar
        return reply_string


    # ---------------------------------------------------------------------
    # input: array of one-hot vectors
    # output: sentence as a string, array of category indexes
    # e.g. -> [[0 0 1], [0 1 0]...] -> "john", [10, 5, 20...]
    def decode_vector(self, sentence_vectors):
        xlen = len(sentence_vectors)
        reply = []
        for i in range(xlen):
            cat_idx = np.argmax(sentence_vectors[i])
            reply.append(cat_idx)
        return reply


    # ---------------------------------------------------------------------
    # builds the training data structures
    # input: an array of sentence strings
    # output: array of [[one-hot vectors], [target category indexes]]
    def build_training_data(self, sentences):
        reply = []
        for sentence in sentences:
            encoding = self.encode_sentence(sentence)
            cat_idx = self.decode_vector(encoding)
            reply.append([encoding, cat_idx])
        return reply



    # ---------------------------------------------------------------------
    def train(self, training_data, epochs = 100, learning_rate = 0.01, print_stats = 0, early_stop_loss = -1.0, batch_size = -1):

        start_time = time.time()

        if batch_size < 1: batch_size = len(training_data)
        min_batch_size = batch_size // 2

        # build the training data structues used during training (encoding etc...)
        if print_stats > 0: print("building internal representation of training data...")
        train_data = self.build_training_data(training_data)

        # define the model 
        self.model = LstmModel(feature_dim = self.FEATURE_DIM, hidden_dim = self.MAX_LEN)
        self.model.to(self.device)

        # Define the loss and optimizer functions
        self.loss_fn = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr = learning_rate)    # converges much faster than SGD
        #self.optimizer = torch.optim.SGD(self.model.parameters(), lr = learning_rate, momentum=0.9)

        if print_stats > 0: prj.print_write('starting model training...')

        for epoch in range(1, epochs + 1):

            # Make an entire pass (an 'epoch') over the training data in batch_size chunks
            average_loss = 0;
            average_loss_ctr = 0;
            for i in range(0, len(train_data), batch_size):
                if print_stats > 0 and epoch % print_stats == 0:
                    print('epoch: {}/{}....'.format(epoch, epochs), end=' ')
                    print("batch: {0}".format(i), end='\r') 

                # don't process batchs less than 1/2 the amount expected
                # small batches might give wild loss values leading to bad gradients
                if len(train_data) - i >= min_batch_size:
                    end_i = i + batch_size
                    train_data_batch = train_data[i:end_i]
                    loss = self.train_batch(train_data_batch)
                    average_loss += loss.item()
                    average_loss_ctr += 1
                else:
                    pass
            
            average_loss = average_loss / average_loss_ctr

            if print_stats > 0:
                if epoch % print_stats == 0:
                    print('epoch: {}/{}...'.format(epoch, epochs), end=' ')
                    #print("loss: {:.4f}".format(loss.item()))
                    print("loss: {:.4f}".format(average_loss))

            if average_loss < early_stop_loss: break

        if print_stats > 0:
            prj.print_write('\n------------------------')
            prj.print_write('Epoch: {}/{}.............'.format(epoch, epochs), end=' ')
            prj.print_write("Loss: {:.4f}".format(average_loss))

        end_time = time.time()
        prj.print_write("Elapsed time was %g seconds" % (end_time - start_time))

        return


    # ---------------------------------------------------------------------
    # training...
    def train_batch(self, batch_data):

        self.optimizer.zero_grad() # clear existing gradients from the previous epoch

        #input_seq = torch.Tensor([x[0] for x in batch_data])
        input_seq = torch.Tensor([x[0][:-1] for x in batch_data]).to(self.device)
        output, hidden = self.model(input_seq)

        output = output.to(self.device)

        #target_seq_idx = torch.Tensor([x[1] for x in batch_data])
        target_seq_idx = torch.Tensor([x[1][1:] for x in batch_data])
        tseq = target_seq_idx.view(-1).long().to(self.device)
        
        loss = self.loss_fn(output, tseq)
        self.model.zero_grad()
        loss.backward() # Does backpropagation and calculates gradients
    
        self.optimizer.step() # Updates the weights accordingly

        return loss


    # ---------------------------------------------------------------------
    def predict_next_character(self, sentence):
        self.model.eval()

        enc = self.encode_sentence(sentence)
        input_seq = torch.Tensor([x for x in enc[:len(sentence)]]).unsqueeze(0).to(self.device)

        out, hidden = self.model(input_seq)

        prob = nn.functional.softmax(out[-1], dim=0).data
        next_char = self.one_hot_decode(prob)

        return next_char


    # ---------------------------------------------------------------------
    # generates a complete sentence givin a start sequence
    def speak(self, out_len, sentence=' '):
        size = out_len - len(sentence)

        # Now pass in the previous characters and get a new one
        for i in range(size):
            char = self.predict_next_character(sentence)
            sentence += char
    
        sentence = sentence.replace('\n', '')

        return sentence

    
    # ---------------------------------------------------------------------
    # generates the next word givin a start sequence
    def speak_next_word(self, start_of_sentence):
        sentence = start_of_sentence
        terminator_chars = keep_chars = [' ', '.', '?', '\n']
        next_word = ''

        idx = 0
        while idx < prj.MAX_WORD_LEN:
            char = self.predict_next_character(sentence)
            if char in terminator_chars:
                break
            else:
                next_word += char
                sentence += char
    
        return next_word


    # ---------------------------------------------------------------------
    # generates the next sentence from the words provided
    # note the 1st letter of the provided words are used to seed the 
    # next predicted word
    # prev_word_max is used to limit the number of previous words are
    # used in the sentence to predict the next word
    def speak_next_from_current(self, words, prev_word_max):
        idx = 0
        gen_words = []
        while idx < len(words):
            sentence = ''
            beg = idx - prev_word_max
            if beg < 0: beg = 0
            for i in range(beg,idx):
                sentence += words[i] + ' '
            next_char = words[idx][0]
            sentence += next_char
            gen_words.append(next_char + self.speak_next_word(sentence))
            idx += 1
        return gen_words


    # ---------------------------------------------------------------------
    def save(self, filename):
        with open(filename, 'wb') as output:  # Overwrites any existing file.
            pickle.dump(self, output, pickle.HIGHEST_PROTOCOL)


    # ---------------------------------------------------------------------
    def load(filename):
        reply = None
        with open(filename, "rb") as input_file:
            reply = pickle.load(input_file)
        reply.model.lstm.flatten_parameters()
        return reply


# ---------------------------------------------------------------------
# base code taken from PyTorch LSTM example: 
# https://pytorch.org/tutorials/beginner/nlp/sequence_models_tutorial.html
# ---------------------------------------------------------------------
class LstmModel(nn.Module):
    def __init__(self, feature_dim, hidden_dim):
        super(LstmModel, self).__init__()

        # use GPU if available
        if torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")
        
        self.hidden_dim = hidden_dim
        self.n_layers = 1

        # The GRU takes word embeddings as inputs, and outputs hidden states
        # with dimensionality hidden_dim.
        #self.lstm = nn.LSTM(feature_dim, hidden_dim, self.n_layers, batch_first=True)
        # changed to GRU model as it produced better results 
        # (note: kept class name of LSTM because serialized data was already produced prior)
        self.lstm = nn.GRU(feature_dim, hidden_dim, self.n_layers, batch_first=True)

        # The linear layer that maps from hidden state space to tag space
        #self.hidden2tag = nn.Linear(hidden_dim * hidden_dim, tagset_size)
        self.hidden2tag = nn.Linear(hidden_dim, feature_dim)

    def forward(self, sentence_vector):
    
        batch_size = sentence_vector.size(0)
        hidden = torch.zeros(self.n_layers, batch_size, self.hidden_dim).to(self.device)

        lstm_out, hidden = self.lstm(sentence_vector)
        
        for_linear_nn = lstm_out.contiguous().view(-1, self.hidden_dim)
        tag_space = self.hidden2tag(for_linear_nn)

        tag_scores = F.log_softmax(tag_space, dim=1)

        return tag_scores, hidden



