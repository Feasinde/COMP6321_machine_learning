# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# Manage the language model scores 
# needed for classification
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
import numpy as np
import pandas as pd 
import comp6321_module as prj

from speaker_by_character_module import *
from measure_speaker_module import *


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
class Pan2012Data():
    def __init__(self, p_langauge_model_fn, v_langauge_model_fn, n_langauge_model_fn):
        
        #self.df = pd.DataFrame(columns = ["type_flg", "conv_id", "author_id", "chat_line", "p_rate", "v_rate", "n_rate"])
        self.df = None
        
        prj.print_write('loading speaker models....')
        self.p_speaker = SpeakerByCharacter.load(p_langauge_model_fn)
        self.v_speaker = SpeakerByCharacter.load(v_langauge_model_fn)
        self.n_speaker = SpeakerByCharacter.load(n_langauge_model_fn)

        return


    # ---------------------------------------------------------------------
    def get_words(self, sentence):
        words = list(filter(None, re.split('[ ]|(\.|\?|\n)', sentence)))
        return words


    # ---------------------------------------------------------------------
    def get_list_of_authors(self, df, xtype, summary_text, n_samples):
        
        ids = df.author_id[df.type_flg == xtype].unique()
        ids.sort()
        
        if( n_samples > len(ids)): n_samples = len(ids)
        ids = ids[:n_samples]
        prj.print_write('number of ' + summary_text + ' :', len(ids))
        
        return ids

    # ---------------------------------------------------------------------
    def get_list_of_all_authors(self):
        ids = self.df.author_id[:].unique()
        ids.sort()
        ids = ids[:]
        return ids

    # ---------------------------------------------------------------------
    def process_author_conversations(self, df, author_id):

        eval_speaker = MeasureSpeaker()
        rows_list = []

        # get all conversations for the author
        conversation_ids = df.conv_id[df.author_id == author_id].unique()

        # foreach of the authors conversations get all the chat lines 
        # (including those from the author (e.g. victim)....
        # invoke the speakers to evaluate each chat line,
        # put the data in a list of dictionary items - at the end the data will be saved to a dataframe
        for conversation_id in conversation_ids:
            df_conversation = df[df.conv_id == conversation_id]
            for index, row in df_conversation.iterrows():
                chat = row['chat_line']
                xtype = row['type_flg']
                words = self.get_words(chat)
                p_words = self.p_speaker.speak_next_from_current(words, prj.PREV_WORD_MAX)
                v_words = self.v_speaker.speak_next_from_current(words, prj.PREV_WORD_MAX)
                n_words = self.n_speaker.speak_next_from_current(words, prj.PREV_WORD_MAX)
                p_rate, v_rate, n_rate = eval_speaker.evaluate_words(xtype, words, p_words, v_words, n_words)
                ndict = {'type_flg': row['type_flg'], 
                         'conv_id': row['conv_id'], 
                         'author_id': row['author_id'], 
                         'chat_line': row['chat_line'], 
                         'p_rate': p_rate, 
                         'v_rate': v_rate, 
                         'n_rate': n_rate}
                rows_list.append(ndict)

        return rows_list


    # ---------------------------------------------------------------------
    def create_training_data(self, df_filename, n_p_samples, n_n_samples):
        
        prj.print_write('creating training data...')

        df = pd.read_pickle(df_filename)
        
        # get list of predators (predator conversations contain the victims)
        p_ids = self.get_list_of_authors(df, 'p', 'preditor/victims', n_p_samples)
        n_ids = self.get_list_of_authors(df, 'x', 'normal', n_n_samples)
        author_ids = [x for x in p_ids]
        author_ids.extend(n_ids)
        
        new_training_ready_data = []

        # get the speaker stats for each line
        for i, author_id in enumerate(author_ids):
            prj.print_write('processing conversation {0}/{1} for author: {2}'.format(i+1, len(author_ids), author_id))
            nlist = self.process_author_conversations(df, author_id)
            new_training_ready_data.extend(nlist)

        self.df = pd.DataFrame(new_training_ready_data, columns = ["type_flg", "conv_id", "author_id", "chat_line", "p_rate", "v_rate", "n_rate"])

        return


    # ---------------------------------------------------------------------
    def get_author_data(self, author):
        rows_list = []

        # get all conversations for the author
        conversation_ids = self.df.conv_id[self.df.author_id == author].unique()

        # foreach of the authors conversations get all the chat lines 
        # (including those from the author (e.g. victim)....
        # invoke the speakers to evaluate each chat line,
        # put the data in a list of dictionary items - at the end the data will be saved to a dataframe
        for conversation_id in conversation_ids:
            df_conversation = self.df[self.df.conv_id == conversation_id]
            for index, row in df_conversation.iterrows():
                ndict = {'type_flg': row['type_flg'], 
                         'conv_id': row['conv_id'], 
                         'author_id': row['author_id'], 
                         'chat_line': row['chat_line'], 
                         'p_rate': row['p_rate'], 
                         'v_rate': row['v_rate'], 
                         'n_rate': row['n_rate']}
                rows_list.append(ndict)

        return rows_list
    

    # ---------------------------------------------------------------------
    def save(self, filename=None):
        if not filename: filename = 'language_model_scores.pkl'
        self.df.to_pickle(filename)

    # ---------------------------------------------------------------------
    def load(self, filename=None):
        if not filename: filename = 'language_model_scores.pkl'
        self.df = pd.read_pickle(filename)





