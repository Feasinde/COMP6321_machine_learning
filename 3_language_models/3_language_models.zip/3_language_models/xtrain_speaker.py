# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# Train the 3 required language models:
#   - predator
#   - victim
#   - normal
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------

import numpy as np
import pandas as pd 
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from speaker_by_character_module import *
import comp6321_module as prj


# ---------------------------------------------------------------------
def train_language_model(chats, learning_rate, batch_size, early_stop):

    #prj.clean_print_write()

    # use GPU if available
    is_cuda = torch.cuda.is_available()
    if is_cuda:
        device = torch.device("cuda")
        prj.print_write("GPU is available")
    else:
        device = torch.device("cpu")
        prj.print_write("GPU not available, CPU used")

    speaker = SpeakerByCharacter()
    speaker.setup_encoding_from_sample_data(chats, prj.MAX_CHAT_LEN)

    prj.print_write("max chat length {0}".format(getattr(speaker, 'MAX_LEN')))
    prj.print_write("feature length {0}".format(getattr(speaker, 'FEATURE_DIM')))

    prj.print_write('model params:', 'learning rate=', learning_rate, 'batch size=', batch_size)

    speaker.train(chats, epochs = 150, learning_rate = learning_rate, print_stats = 1, early_stop_loss = early_stop, batch_size = batch_size)

    return speaker


# ---------------------------------------------------------------------
# save the training chats into a file (useful for analysis)
def save_chats_as_text(chats, filename):

    with open(filename, 'w+') as f:
        for i in range(len(chats)):
            f.write(chats[i] + "\n")


# ---------------------------------------------------------------------
def run_some_samples(speaker):
    prj.print_write('\n------------------------')
    prj.print_write('some samples....')

    prj.print_write(speaker.speak(50, 'yea'))
    prj.print_write(speaker.speak(50, 'i '))
    prj.print_write(speaker.speak(50, 'you '))
    prj.print_write(speaker.speak(50, 'yes'))
    prj.print_write(speaker.speak(50, 'good'))
    prj.print_write(speaker.speak(50, 'ha'))
    prj.print_write(speaker.speak(50, 'why'))
    prj.print_write(speaker.speak(50))


# ---------------------------------------------------------------------
def build_predator_language_model(dataset_filename, number_of_training_samples, learning_rate, batch_size, early_stop, save_model_to_fn):

    # get the PAN2012 chats from the preprocessed dataset
    prj.print_write('reading in chat data from:', dataset_filename)
    df = pd.read_pickle(dataset_filename)

    # train the predator language model
    chats = df.chat_line[df.type_flg == 'p'].astype(str).values.tolist()[0:number_of_training_samples]
    save_chats_as_text(chats, './data/trained_predator_chatlines.txt')
    prj.print_write('number of predator chats: ', len(chats))

    speaker = train_language_model(chats, learning_rate, batch_size, early_stop)

    prj.print_write('saving model to:', save_model_to_fn)
    speaker.save(save_model_to_fn)


# ---------------------------------------------------------------------
def build_victim_language_model(dataset_filename, number_of_training_samples, learning_rate, batch_size, early_stop, save_model_to_fn):

    # get the PAN2012 chats from the preprocessed dataset
    prj.print_write('reading in chat data from:', dataset_filename)
    df = pd.read_pickle(dataset_filename)

    # train the victim language model
    chats = df.chat_line[df.type_flg == 'v'].astype(str).values.tolist()[0:number_of_training_samples]
    save_chats_as_text(chats, './data/trained_victim_chatlines.txt')
    prj.print_write('number of victim chats: ', len(chats))

    speaker = train_language_model(chats, learning_rate, batch_size, early_stop)

    prj.print_write('saving model to:', save_model_to_fn)
    speaker.save(save_model_to_fn)


# ---------------------------------------------------------------------
def build_normal_language_model(dataset_filename, number_of_training_samples, learning_rate, batch_size, early_stop, save_model_to_fn):

    # get the PAN2012 chats from the preprocessed dataset
    prj.print_write('reading in chat data from:', dataset_filename)
    df = pd.read_pickle(dataset_filename)

    # train the normal language model
    chats = df.chat_line[df.type_flg == 'x'].astype(str).values.tolist()[0:number_of_training_samples]
    save_chats_as_text(chats, './data/trained_normal_chatlines.txt')
    prj.print_write('number of normal chats: ', len(chats))
    
    speaker = train_language_model(chats, learning_rate, batch_size, early_stop)

    prj.print_write('saving model to:', save_model_to_fn)
    speaker.save(save_model_to_fn)




