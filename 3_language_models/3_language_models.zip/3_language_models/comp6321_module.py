# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# 
# common module holding helper functions and constants
#
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------
import os

MAX_CHAT_LEN = 128
MAX_WORD_LEN = 12

# used when asking the speaker to generate a new word from a sentence
PREV_WORD_MAX = 10  

def clean_print_write():
    try:
        os.remove("output.txt")
    except OSError:
        pass
    return

def print_write(*args, **kwargs):
    print(*args, **kwargs)
    print(*args, **kwargs, file=open("output.txt", "a"))
    return

def xwrite(*args, **kwargs):
    print(*args, **kwargs, file=open("output.txt", "a"))
    return

