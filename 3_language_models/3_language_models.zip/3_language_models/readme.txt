# ---------------------------------------------------------------------
# COMP 6321 - Machine Learning
# Final Project Code
# Author: John Sekeres
# Student ID: 25672953
# ---------------------------------------------------------------------

prerequisites:
python 3.7


1. edit main.py to include the parts you'd like to run
   (by default everything is included - might take long)
   
2. run main.py

