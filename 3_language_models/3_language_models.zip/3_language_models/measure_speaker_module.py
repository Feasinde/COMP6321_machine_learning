# ---------------------------------------------------------------------
import numpy as np
import comp6321_module as prj


C_IDX = 0   # counter index
P_IDX = 1   # predator index
V_IDX = 2   # victim index
N_IDX = 3   # normal index
X_IDX = 4   # unknown index (happens when there is no highest prediction)


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
class MeasureSpeaker():
    def __init__(self):
        self.p_stats = np.zeros(5, dtype=np.int32)
        self.v_stats = np.zeros(5, dtype=np.int32)
        self.n_stats = np.zeros(5, dtype=np.int32)
        return


    # ---------------------------------------------------------------------
    def word_match(self, word1, word2):
        len1 = len(word1)
        len2 = len(word2)
        max_len = max(len1, len2)
        match_ctr = 0
        i = 0
        while i < max_len:
            if i < len1 and i < len2:
                if word1[i] == word2[i]:
                    match_ctr += 1
            else:
                break
            i += 1

        reply = match_ctr / max_len
        return reply


    # ---------------------------------------------------------------------
    def sentence_match(self, orginal_words, predicted_words):
        len1 = len(orginal_words)
        len2 = len(predicted_words)
        max_len = max(len1, len2)
        match_ctr = 0
        i = 0
        while i < max_len:
            if i < len1 and i < len2:
                diff = self.word_match(orginal_words[i], predicted_words[i])
                match_ctr += diff
            else:
                break
            i += 1

        reply = match_ctr / max_len
        return reply


    # ---------------------------------------------------------------------
    def evaluate_words(self, target_type, target_words, p_words, v_words, n_words):
        
        p_rate = self.sentence_match(target_words, p_words)
        v_rate = self.sentence_match(target_words, v_words)
        n_rate = self.sentence_match(target_words, n_words)

        idx = X_IDX
        if p_rate > v_rate and p_rate > n_rate:
            idx = P_IDX
        else:
            if v_rate > p_rate and v_rate > n_rate:
                idx = V_IDX
            else:
                if n_rate > p_rate and n_rate > v_rate:
                    idx = N_IDX

        if target_type == 'p':
            self.p_stats[C_IDX] += 1
            self.p_stats[idx] += 1
        else:
            if target_type == 'v':
                self.v_stats[C_IDX] += 1
                self.v_stats[idx] += 1
            else:
                if target_type == 'x':
                    self.n_stats[C_IDX] += 1
                    self.n_stats[idx] += 1
                else:
                    raise Exception('invalid target type')
        
        return p_rate, v_rate, n_rate


    # ---------------------------------------------------------------------
    def chat_counters(self, stats):
        total_ctr = stats[C_IDX]
        p_ctr = stats[P_IDX]
        v_ctr = stats[V_IDX]
        n_ctr = stats[N_IDX]
        unknown_ctr = stats[X_IDX]
        return total_ctr, p_ctr, v_ctr, n_ctr, unknown_ctr

    def pchat_counters(self):
        return self.chat_counters(self.p_stats)
    
    def vchat_counters(self):
        return self.chat_counters(self.v_stats)
    
    def nchat_counters(self):
        return self.chat_counters(self.n_stats)
    
    
    # ---------------------------------------------------------------------
    def p_true_positive(self):
        x = 0
        x += self.p_stats[P_IDX]
        return x
    def p_true_negative(self):
        x = 0
        x += self.v_stats[V_IDX]
        x += self.v_stats[N_IDX]
        x += self.v_stats[X_IDX]
        x += self.n_stats[V_IDX]
        x += self.n_stats[N_IDX]
        x += self.n_stats[X_IDX]
        return x
    def p_false_positive(self):
        x = 0
        x += self.v_stats[P_IDX]
        x += self.n_stats[P_IDX]
        return x
    def p_false_negative(self):
        x = 0
        x += self.p_stats[V_IDX]
        x += self.p_stats[N_IDX]
        x += self.p_stats[X_IDX]
        return x

    # ---------------------------------------------------------------------
    def v_true_positive(self):
        x = 0
        x += self.v_stats[V_IDX]
        return x
    def v_true_negative(self):
        x = 0
        x += self.p_stats[P_IDX]
        x += self.p_stats[N_IDX]
        x += self.p_stats[X_IDX]
        x += self.n_stats[P_IDX]
        x += self.n_stats[N_IDX]
        x += self.n_stats[X_IDX]
        return x
    def v_false_positive(self):
        x = 0
        x += self.p_stats[V_IDX]
        x += self.n_stats[V_IDX]
        return x
    def v_false_negative(self):
        x = 0
        x += self.v_stats[P_IDX]
        x += self.v_stats[N_IDX]
        x += self.v_stats[X_IDX]
        return x

    # ---------------------------------------------------------------------
    def n_true_positive(self):
        x = 0
        x += self.n_stats[N_IDX]
        return x
    def n_true_negative(self):
        x = 0
        x += self.p_stats[P_IDX]
        x += self.p_stats[V_IDX]
        x += self.p_stats[X_IDX]
        x += self.v_stats[P_IDX]
        x += self.v_stats[V_IDX]
        x += self.v_stats[X_IDX]
        return x
    def n_false_positive(self):
        x = 0
        x += self.p_stats[N_IDX]
        x += self.v_stats[N_IDX]
        return x
    def n_false_negative(self):
        x = 0
        x += self.n_stats[P_IDX]
        x += self.n_stats[V_IDX]
        x += self.n_stats[X_IDX]
        return x
           
    # ---------------------------------------------------------------------
    def p_accuracy(self):
        acc = (self.p_true_positive() + self.p_true_negative()) / (self.p_true_positive() + self.p_true_negative() + self.p_false_positive() + self.p_false_negative())
        return acc
    def p_precision(self):
        p = self.p_true_positive() / (self.p_true_positive() + self.p_false_positive())
        return p
    def p_recall(self):
        p = self.p_true_positive() / (self.p_true_positive() + self.p_false_negative())
        return p

    # ---------------------------------------------------------------------
    def v_accuracy(self):
        acc = (self.v_true_positive() + self.v_true_negative()) / (self.v_true_positive() + self.v_true_negative() + self.v_false_positive() + self.v_false_negative())
        return acc
    def v_precision(self):
        p = self.v_true_positive() / (self.v_true_positive() + self.v_false_positive())
        return p
    def v_recall(self):
        p = self.v_true_positive() / (self.v_true_positive() + self.v_false_negative())
        return p

    # ---------------------------------------------------------------------
    def n_accuracy(self):
        acc = (self.n_true_positive() + self.n_true_negative()) / (self.n_true_positive() + self.n_true_negative() + self.n_false_positive() + self.n_false_negative())
        return acc
    def n_precision(self):
        p = self.n_true_positive() / (self.n_true_positive() + self.n_false_positive())
        return p
    def n_recall(self):
        p = self.n_true_positive() / (self.n_true_positive() + self.n_false_negative())
        return p



